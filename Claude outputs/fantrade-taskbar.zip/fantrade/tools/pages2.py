# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import head, atmosphere, nav, footer, ic, JS_SHELL, qr_svg, QR_ADDRESS

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
ARROW = '<span class="cap">' + ic("arrow", "ic") + '</span>'


def T(tpl, *args):
    out = tpl
    for a in args:
        out = out.replace("@@", str(a), 1)
    return out


def btn(label, cls="btn-lime", href="#", tag="a", extra=""):
    return '<%s class="btn %s" %s %s>%s%s</%s>' % (
        tag, cls, ('href="%s"' % href) if tag == "a" else "", extra, label, ARROW, tag)


def page(fname, title, body, js="", css="", app=False):
    html = (head(title, css) + atmosphere() + nav(fname, app) +
            body + footer() + "<script>(function(){" + JS_SHELL + js + "})();</script></body></html>")
    open(os.path.join(OUT, fname), "w", encoding="utf-8").write(html)


# ══════════════════════════════════════════════════════════
# $FTR WALLET
# ══════════════════════════════════════════════════════════
FTR_CSS = """
.wal-head{display:flex;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:2px}
.wal-head .k-label{margin:0}
.tx{display:grid;grid-template-columns:1.6fr 1fr 1fr 1fr;gap:14px;padding:15px 24px;
  border-bottom:1px solid rgba(255,255,255,.05);font-size:13px;align-items:center}
.tx.h{font-weight:600;font-size:9.5px;letter-spacing:.16em;color:var(--faint);text-transform:uppercase;
  border-bottom:1px solid var(--hair)}
.tx:last-child{border-bottom:0}
.tx .w{display:flex;align-items:center;gap:11px;min-width:0}
.tx .w span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dist{display:flex;align-items:center;gap:26px;flex-wrap:wrap}
.dist .key{display:flex;flex-direction:column;gap:12px;flex:1;min-width:180px}
.dist .kr{display:flex;align-items:center;gap:11px;font-size:13px;color:var(--dim)}
.dist .kr i{width:10px;height:10px;border-radius:3px;display:block;flex:none}
.dist .kr b{margin-left:auto;font-family:'JetBrains Mono',monospace;color:var(--ink);font-weight:400}
.maxbtn{border:1px solid rgba(196,248,42,.3);background:rgba(196,248,42,.09);color:var(--lime);
  border-radius:999px;padding:5px 12px;font-weight:600;font-size:9px;letter-spacing:.12em;
  text-transform:uppercase;cursor:pointer;flex:none;transition:all .5s var(--ease)}
.maxbtn:hover{background:rgba(196,248,42,.18)}
@media (max-width:768px){
  .tx{grid-template-columns:1.4fr 1fr;padding:13px 14px}
  .tx>*:nth-child(n+3){display:none}
}
"""

# label, icon, coin tone, sparkline direction
WALLET_ASSETS = [("$Saka", "Bukayo Saka", "boot", "", 6.4, 0),
                 ("$Haaland", "Erling Haaland", "boot", "", -1.8, 1),
                 ("$Bruno", "Bruno Fernandes", "boot", "", 4.2, 2),
                 ("$Arteta", "Mikel Arteta", "whistle", "am", 14.2, 9)]

f = [T('<main><section class="app-head"><div class="wrap"><div class="head-row">'
       '<div><span class="pill" data-reveal>@@ The platform currency</span>'
       '<h1 data-reveal>Your<br>wallet</h1>'
       '<p class="lede" data-reveal>One balance funds everything. Shares clear in $FTR, swap fees settle in $FTR, '
       'FanPlay stakes lock in $FTR, and every settled round pays back into the same wallet.</p></div>'
       '<div class="acts" data-reveal>@@@@</div></div>'
       '<div class="statbar" data-reveal>'
       '<div>@@ Available <b data-bind="balance">128,450</b> $FTR</div>'
       '<div>@@ Locked in entries <b data-bind="locked">5,000</b></div>'
       '<div>@@ Held in shares <b data-bind="assets">402,610</b></div>'
       '<div>@@ Earned this season <b data-bind="earned">19,640</b></div>'
       '</div></div></section>',
       ic("coin", "ic"),
       btn("Deposit", tag="button", extra='id="depositBtn"'),
       btn("Withdraw", "btn-glass", tag="button", extra='id="withdrawBtn"'),
       ic("wallet", "ic"), ic("lock", "ic"), ic("supply", "ic"), ic("trophy", "ic"))]

f.append('<section style="padding:10px 0 120px"><div class="wrap"><div class="bento">')

# ── balance hero ──
f.append(T('<div class="bezel c7" data-reveal><div class="core pad">'
           '<div class="wal-head"><div><div class="k-label">Total balance</div>'
           '<div class="bal-big" id="walBal">128,450<small> $FTR</small></div>'
           '<div class="bal-delta" id="walDelta">@@<span>2.35% today</span>'
           '<em id="walGbp">≈ £10,358</em></div></div>'
           '<div style="margin-left:auto;text-align:right">'
           '<div class="k-label">Wallet</div>'
           '<div class="num" style="font-size:13px">FTR-012</div>'
           '<div class="sub-line">Non-custodial</div></div></div>'
           '<div class="bal-chart" id="walChart"></div>'
           '<div class="range" id="walRange">'
           '<button type="button" aria-pressed="true" data-r="1D">1D</button>'
           '<button type="button" aria-pressed="false" data-r="1W">1W</button>'
           '<button type="button" aria-pressed="false" data-r="1M">1M</button>'
           '<button type="button" aria-pressed="false" data-r="1Y">1Y</button>'
           '<button type="button" aria-pressed="false" data-r="All">All</button></div>'
           '<div class="acts4" id="walActs">'
           '<button type="button" aria-pressed="false" data-p="send">@@<span>Send</span></button>'
           '<button type="button" aria-pressed="true" data-p="receive">@@<span>Receive</span></button>'
           '<button type="button" aria-pressed="false" data-p="swap">@@<span>Swap</span></button>'
           '<button type="button" aria-pressed="false" data-p="buy">@@<span>Buy</span></button>'
           '</div></div></div>',
           ic("arrow", "ic"), ic("arrow", "ic"), ic("hand", "ic"), ic("swap", "ic"), ic("coin", "ic")))

# ── action panel ──
f.append('<div class="bezel c5" data-reveal><div class="core pad">')

# receive
f.append(T('<div class="pane on" data-pane="receive">'
           '<div style="display:flex;align-items:center;gap:12px;margin-bottom:18px">'
           '<div class="k-label" style="margin:0">Receive $FTR</div>'
           '<span class="listening" style="margin-left:auto"><i></i>Listening</span></div>'
           '<button class="netsel" type="button" id="netSel">'
           '<span class="coin lime">@@</span>'
           '<span style="min-width:0"><span class="k">Network</span>'
           '<span class="v" id="netName">Fantrade L2 · Mainnet</span></span>'
           '<span class="chev"></span></button>'
           '<div class="qr">@@<span class="mark">@@</span></div>'
           '<div class="addr" id="walAddr"></div>'
           '@@'
           '<div class="warn">@@<p>Send only $FTR and Fantrade-issued share tokens to this address. '
           'Anything else sent here is unrecoverable.</p></div>'
           '</div>',
           ic("layers", "ic"), qr_svg(), ic("ball", "ic"),
           btn("Copy address", tag="button",
               extra='id="copyAddr" style="width:100%;justify-content:space-between"'),
           ic("flag", "ic")))

# send
f.append(T('<div class="pane" data-pane="send">'
           '<div class="k-label">Send $FTR</div>'
           '<div class="tf" id="f-sendTo"><label for="sendTo">To manager or address</label>'
           '<div class="inp">@@<input id="sendTo" type="text" placeholder="@handle or 0x…"></div>'
           '<div class="err">Enter a handle or a wallet address.</div></div>'
           '<div class="field"><label>Amount</label><input id="sendAmt" value="2,500" inputmode="numeric">'
           '</div>'
           '<div class="quick"><button data-sa="1000">1,000</button><button data-sa="5000">5,000</button>'
           '<button data-sa="10000">10,000</button><button type="button" class="maxbtn" id="sendMax">Max</button></div>'
           '<div class="line"><span>Network fee</span><b>0 $FTR · covered</b></div>'
           '<div class="line"><span>Arrives</span><b>Instantly</b></div>'
           '<div class="line"><span>Balance after</span><b id="sendAfter">125,950 $FTR</b></div>'
           '@@'
           '<div class="warn">@@<p>Transfers between Fantrade managers are final. Check the handle before '
           'you send — there is no reversal.</p></div>'
           '</div>',
           ic("user", "ic"),
           btn("Send $FTR", tag="button",
               extra='id="sendGo" style="width:100%;justify-content:space-between;margin-top:18px"'),
           ic("flag", "ic")))

# swap
f.append(T('<div class="pane" data-pane="swap">'
           '<div class="k-label">Swap one asset for another</div>'
           '<div class="tf" id="f-swapFrom"><label for="swapFrom">From</label><div class="inp">@@'
           '<select id="swapFrom"></select><span class="chev"></span></div>'
           '<div class="hint" id="swapHold">—</div></div>'
           '<div class="field"><label>Shares</label><input id="swapQty" value="1,000" inputmode="numeric"></div>'
           '<div class="quick"><button data-sq="250">250</button><button data-sq="500">500</button>'
           '<button data-sq="1000">1,000</button><button type="button" class="maxbtn" id="swapMax">Max</button></div>'
           '<div class="tf" id="f-swapTo" style="margin-top:14px"><label for="swapTo">To</label>'
           '<div class="inp">@@<select id="swapTo"></select><span class="chev"></span></div></div>'
           '<div class="line"><span>You give</span><b id="swGive">—</b></div>'
           '<div class="line"><span>Swap fee (0.4%)</span><b id="swFee">—</b></div>'
           '<div class="line"><span>You receive</span><b id="swGet">—</b></div>'
           '<div class="line"><span>Dust returned to wallet</span><b id="swDust">—</b></div>'
           '@@</div>',
           ic("swap", "ic"), ic("target", "ic"),
           btn("Swap assets", tag="button",
               extra='id="swapGo" style="width:100%;justify-content:space-between;margin-top:18px"')))

# buy
f.append(T('<div class="pane" data-pane="buy">'
           '<div class="k-label">Buy $FTR</div>'
           '<div class="field"><label>You pay</label><input id="fiat" value="1,000" inputmode="numeric"></div>'
           '<div style="display:flex;align-items:center;gap:12px;margin:6px 0 4px">@@'
           '<span style="color:var(--faint);font-size:12.5px">1 GBP = 12.40 $FTR · rate held for 30s</span></div>'
           '<div class="field"><label>You receive</label><input id="ftr" value="12,400" readonly></div>'
           '<div class="quick"><button data-f="100">£100</button><button data-f="500">£500</button>'
           '<button data-f="1000">£1,000</button><button data-f="5000">£5,000</button></div>'
           '<div class="line"><span>Conversion fee (0.5%)</span><b id="cFee">62</b></div>'
           '<div class="line"><span>Credited</span><b id="cNet">12,338 $FTR</b></div>'
           '<div class="line"><span>Settles</span><b>Instantly</b></div>'
           '@@'
           '<p style="font-size:11.5px;color:var(--faint);font-weight:300;margin-top:16px;line-height:1.6">'
           'Prototype build — no card is charged and no money moves. The rate shown is illustrative.</p>'
           '</div>',
           ic("swap", "ic"),
           btn("Convert to $FTR", tag="button",
               extra='id="convertBtn" style="width:100%;justify-content:space-between;margin-top:18px"')))

f.append('</div></div>')

# ── my assets ──
f.append(T('<div class="bezel c12" data-reveal><div class="core">'
           '<div style="padding:30px 24px 16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">'
           '<div><div style="font-family:Archivo;font-variation-settings:\'wdth\' 120,\'wght\' 800;'
           'text-transform:uppercase;font-size:19px">My assets</div>'
           '<div class="sub-line" id="walCount">Loading…</div></div>'
           '<a href="portfolio.html" style="margin-left:auto;font-size:11.5px;color:var(--lime);'
           'display:flex;align-items:center;gap:8px">See all @@</a></div>'
           '<div id="walAssets"></div></div></div>', ic("arrow", "ic-sm")))

# ── activity ──
f.append(T('<div class="bezel c7" data-reveal><div class="core">'
           '<div style="padding:30px 24px 18px;display:flex;align-items:center;gap:12px;flex-wrap:wrap">'
           '<div><div style="font-family:Archivo;font-variation-settings:\'wdth\' 120,\'wght\' 800;'
           'text-transform:uppercase;font-size:19px">Wallet activity</div>'
           '<div class="sub-line">Every movement in and out of this balance</div></div>'
           '<a href="portfolio.html" style="margin-left:auto;font-size:11.5px;color:var(--lime)">'
           'Full ledger</a></div>'
           '<div class="tx h"><span>Activity</span><span>Type</span><span>Points</span><span>$FTR</span></div>'
           '<div id="ledgerBody"></div></div></div>'))

# ── supply ──
f.append(T('<div class="bezel c5" data-reveal><div class="core pad">'
           '<div class="k-label">Circulating supply</div>'
           '<div class="dist" style="margin-top:10px">'
           '<svg viewBox="0 0 42 42" style="width:118px;height:118px;flex:none">'
           '<circle cx="21" cy="21" r="15.9" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="5"/>'
           '<circle cx="21" cy="21" r="15.9" fill="none" stroke="#C4F82A" stroke-width="5" '
           'stroke-dasharray="46 54" stroke-dashoffset="25" transform="rotate(-90 21 21)"/>'
           '<circle cx="21" cy="21" r="15.9" fill="none" stroke="#FF6A1F" stroke-width="5" '
           'stroke-dasharray="28 72" stroke-dashoffset="79" transform="rotate(-90 21 21)"/>'
           '<circle cx="21" cy="21" r="15.9" fill="none" stroke="rgba(255,255,255,.28)" stroke-width="5" '
           'stroke-dasharray="14 86" stroke-dashoffset="51" transform="rotate(-90 21 21)"/></svg>'
           '<div class="key">'
           '<div class="kr"><i style="background:#C4F82A"></i>Held by fans<b>46%</b></div>'
           '<div class="kr"><i style="background:#FF6A1F"></i>Staked in rounds<b>28%</b></div>'
           '<div class="kr"><i style="background:rgba(255,255,255,.28)"></i>Rewards pool<b>14%</b></div>'
           '<div class="kr"><i style="background:rgba(255,255,255,.08)"></i>Treasury<b>12%</b></div></div></div>'
           '<div class="k-label" style="margin-top:28px">What $FTR does</div>'
           '<div class="rowlink">@@ Clears every exchange order<b>0.4% fee</b></div>'
           '<div class="rowlink">@@ Settles swap differences<b>0.4% fee</b></div>'
           '<div class="rowlink">@@ Locks FanPlay stakes<b>No fee</b></div>'
           '<div class="rowlink">@@ Pays out settled rounds<b>No fee</b></div>'
           '<p style="font-size:11.5px;color:var(--faint);font-weight:300;margin-top:18px;line-height:1.6">'
           'Locked balances are shown separately and release the moment a settlement window closes.</p>'
           '</div></div>',
           ic("candle", "ic"), ic("swap", "ic"), ic("bolt", "ic"), ic("trophy", "ic")))

f.append('</div></div></section></main>')

FTR_JS = ("var WASSETS=" + repr([{"t": t, "n": n, "i": i, "c": c, "d": d, "s": s}
                                 for t, n, i, c, d, s in WALLET_ASSETS]).replace("'", '"') + ";"
          + "var WADDR=" + ('"%s"' % QR_ADDRESS) + ";") + r"""
function el(id){ return document.getElementById(id); }
function wrap(id){ return document.getElementById('f-' + id); }
function num(v){ return parseInt(String(v).replace(/[^0-9]/g, ''), 10) || 0; }
function money(n){ return Math.round(n).toLocaleString('en-US'); }

// ── address, coloured in four-character groups so it can be eyeballed ──
(function(){
  var cols = ['var(--lime)', 'var(--amber)', '#4DA6FF', 'var(--ink)'];
  var out = '', i = 0;
  while(i < WADDR.length){
    out += '<i style="color:' + cols[(i / 4 | 0) % 4] + '">' + WADDR.slice(i, i + 4) + '</i>';
    i += 4;
  }
  el('walAddr').innerHTML = out;
})();

el('copyAddr').addEventListener('click', function(){
  function done(){ showToast('Receive address copied.', 'success'); }
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(WADDR).then(done, fallback);
  } else { fallback(); }
  function fallback(){
    var ta = document.createElement('textarea');
    ta.value = WADDR; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); done(); }
    catch(e){ showToast('Copy failed — select the address manually.', 'error'); }
    ta.remove();
  }
});

el('netSel').addEventListener('click', function(){
  openModal('<h3 class="ft-modal-title">Receiving network</h3>'
    + '<p class="ft-modal-desc">$FTR settles natively on Fantrade L2. Bridged networks take longer and '
    + 'carry their own gas cost.</p>'
    + '<div class="ft-modal-card">'
    + '<div class="m-row"><span>Fantrade L2 · Mainnet</span><b style="color:var(--lime)">Instant · no gas</b></div>'
    + '<div class="m-row"><span>Ethereum · Mainnet</span><b>~3 min · gas applies</b></div>'
    + '<div class="m-row"><span>Base</span><b>~40 sec · low gas</b></div>'
    + '<div class="m-row total"><span>Polygon</span><b>~1 min · low gas</b></div></div>'
    + '<p style="font-size:11.5px;color:var(--faint);font-weight:300;line-height:1.6;margin:0">'
    + 'Prototype build — the address above is the same on every network.</p>');
});

// ── range pills + chart ──
var SERIES = {
  '1D': series(30, 0.12, 2.6, 11),
  '1W': series(34, 0.35, 3.4, 23),
  '1M': series(40, 0.9, 5.2, 47),
  '1Y': series(48, 1.9, 7.5, 91),
  'All': series(56, 2.6, 9.0, 137)
};
var DELTA = { '1D': 2.35, '1W': 6.10, '1M': 14.82, '1Y': 61.40, 'All': 184.20 };
var WORD = { '1D': 'today', '1W': 'this week', '1M': 'this month', '1Y': 'this year', 'All': 'all time' };
function paint(r){
  drawArea(el('walChart'), SERIES[r], DELTA[r] >= 0);
  var d = el('walDelta');
  d.className = 'bal-delta' + (DELTA[r] >= 0 ? '' : ' down');
  d.querySelector('span').textContent = (DELTA[r] >= 0 ? '' : '') + DELTA[r].toFixed(2) + '% ' + WORD[r];
}
document.querySelectorAll('#walRange button').forEach(function(b){
  b.addEventListener('click', function(){
    document.querySelectorAll('#walRange button').forEach(function(x){ x.setAttribute('aria-pressed', 'false'); });
    b.setAttribute('aria-pressed', 'true');
    paint(b.dataset.r);
  });
});

// ── action panes ──
document.querySelectorAll('#walActs button').forEach(function(b){
  b.addEventListener('click', function(){
    document.querySelectorAll('#walActs button').forEach(function(x){ x.setAttribute('aria-pressed', 'false'); });
    b.setAttribute('aria-pressed', 'true');
    document.querySelectorAll('.pane').forEach(function(p){
      p.classList.toggle('on', p.dataset.pane === b.dataset.p);
    });
  });
});

// ── send ──
function sendAfter(){
  var s = FT.getState();
  el('sendAfter').textContent = money(Math.max(0, s.wallet.balance - num(el('sendAmt').value))) + ' $FTR';
}
el('sendAmt').addEventListener('input', sendAfter);
document.querySelectorAll('[data-sa]').forEach(function(b){
  b.addEventListener('click', function(){
    el('sendAmt').value = (+b.dataset.sa).toLocaleString('en-US'); sendAfter();
  });
});
el('sendMax').addEventListener('click', function(){
  el('sendAmt').value = FT.getState().wallet.balance.toLocaleString('en-US'); sendAfter();
});
el('sendGo').addEventListener('click', function(){
  var to = el('sendTo').value.trim();
  if(to.length < 3){ wrap('sendTo').classList.add('bad'); return; }
  wrap('sendTo').classList.remove('bad');
  try {
    var r = FT.sendFtr(num(el('sendAmt').value), to, 'send');
    showToast(money(r.sent) + ' $FTR sent to ' + to + '.', 'success');
    sendAfter();
  } catch(e){ showToast(e.message, 'error'); }
});

// ── swap ──
var PRICES = {};
WASSETS.forEach(function(a){ PRICES[a.t] = 0; });
function fillSwap(){
  var s = FT.getState(), from = el('swapFrom'), to = el('swapTo');
  var held = Object.keys(s.holdings);
  var all = {};
  held.forEach(function(k){ all[k] = s.holdings[k].p; });
  ASSETS.forEach(function(a){ all[a.t] = a.p; PRICES[a.t] = a.p;
    PRICES[a.t + ':name'] = a.n; PRICES[a.t + ':coach'] = a.c; });
  held.forEach(function(k){ PRICES[k] = s.holdings[k].p; PRICES[k + ':name'] = s.holdings[k].n; });

  var keepFrom = from.value, keepTo = to.value;
  from.innerHTML = held.map(function(k){
    return '<option value="' + k + '">' + k + ' · ' + s.holdings[k].shares.toLocaleString('en-US') + ' shares</option>';
  }).join('') || '<option value="">Nothing held yet</option>';
  to.innerHTML = Object.keys(all).map(function(k){
    return '<option value="' + k + '">' + k + ' · ' + all[k].toFixed(2) + ' $FTR</option>';
  }).join('');
  if(keepFrom && s.holdings[keepFrom]) from.value = keepFrom;
  if(keepTo && all[keepTo]) to.value = keepTo;
  else if(to.value === from.value && to.options.length > 1) to.selectedIndex = 1;
  swapCalc();
}
function swapCalc(){
  var s = FT.getState(), fk = el('swapFrom').value, tk = el('swapTo').value;
  var h = s.holdings[fk];
  if(!h){ ['swGive','swFee','swGet','swDust'].forEach(function(i){ el(i).textContent = '—'; });
    el('swapHold').textContent = 'Buy something on the exchange first.'; return; }
  el('swapHold').textContent = 'You hold ' + h.shares.toLocaleString('en-US') + ' at '
    + h.p.toFixed(2) + ' $FTR.';
  var q = Math.min(num(el('swapQty').value), h.shares);
  var gross = q * h.p, fee = gross * 0.004, net = gross - fee;
  var tp = PRICES[tk] || 0, got = tp ? Math.floor(net / tp) : 0;
  el('swGive').textContent = q.toLocaleString('en-US') + ' ' + fk + ' · ' + money(gross) + ' $FTR';
  el('swFee').textContent = money(fee) + ' $FTR';
  el('swGet').textContent = got.toLocaleString('en-US') + ' ' + tk;
  el('swDust').textContent = money(Math.max(0, net - got * tp)) + ' $FTR';
}
['swapQty'].forEach(function(i){ el(i).addEventListener('input', swapCalc); });
['swapFrom','swapTo'].forEach(function(i){ el(i).addEventListener('change', swapCalc); });
document.querySelectorAll('[data-sq]').forEach(function(b){
  b.addEventListener('click', function(){
    el('swapQty').value = (+b.dataset.sq).toLocaleString('en-US'); swapCalc();
  });
});
el('swapMax').addEventListener('click', function(){
  var h = FT.getState().holdings[el('swapFrom').value];
  if(h){ el('swapQty').value = h.shares.toLocaleString('en-US'); swapCalc(); }
});
el('swapGo').addEventListener('click', function(){
  var fk = el('swapFrom').value, tk = el('swapTo').value;
  if(!fk){ showToast('Nothing to swap yet.', 'error'); return; }
  if(fk === tk){ showToast('Pick two different assets.', 'error'); return; }
  try {
    var r = FT.swapAssets(fk, tk, num(el('swapQty').value), PRICES);
    showToast(r.spent.toLocaleString('en-US') + ' ' + fk + ' swapped for '
      + r.received.toLocaleString('en-US') + ' ' + tk + '.', 'success');
  } catch(e){ showToast(e.message, 'error'); }
});

// ── buy ──
var fi = el('fiat'), fo = el('ftr');
function conv(){
  var v = num(fi.value), gross = v * 12.4, fee = gross * 0.005;
  fo.value = money(gross);
  el('cFee').textContent = money(fee);
  el('cNet').textContent = money(gross - fee) + ' $FTR';
}
fi.addEventListener('input', function(){
  var v = fi.value.replace(/[^0-9]/g, '');
  fi.value = v ? (+v).toLocaleString('en-US') : '';
  conv();
});
document.querySelectorAll('[data-f]').forEach(function(b){
  b.addEventListener('click', function(){ fi.value = (+b.dataset.f).toLocaleString('en-US'); conv(); });
});
el('convertBtn').addEventListener('click', function(){
  var v = num(fi.value);
  if(v <= 0){ showToast('Enter an amount in GBP to convert.', 'error'); return; }
  var net = FT.convertGbp(v);
  showToast('£' + v.toLocaleString('en-US') + ' converted into ' + net.toLocaleString('en-US') + ' $FTR.', 'success');
});

// ── my assets ──
function renderAssets(){
  var s = FT.getState(), box = el('walAssets');
  var rows = ['<div class="arow"><div class="who"><span class="coin lime">'
    + '<svg class="ic" aria-hidden="true"><use href="#i-coin"/></svg></span>'
    + '<div style="min-width:0"><div class="nm">$FTR</div><div class="qt">Liquid balance</div></div></div>'
    + '<div data-spark="1"></div>'
    + '<div><div class="val">' + money(s.wallet.balance) + '</div>'
    + '<div class="chg up">+2.35%</div></div></div>'];

  Object.keys(s.holdings).forEach(function(k){
    var h = s.holdings[k];
    var meta = WASSETS.filter(function(a){ return a.t === k; })[0]
      || { i: h.c ? 'whistle' : 'boot', c: h.c ? 'am' : '', d: 0, s: 0 };
    var up = meta.d >= 0;
    rows.push('<div class="arow"><div class="who"><span class="coin ' + (meta.c || '') + '">'
      + '<svg class="ic" aria-hidden="true"><use href="#i-' + meta.i + '"/></svg></span>'
      + '<div style="min-width:0"><div class="nm">' + h.n + '</div>'
      + '<div class="qt">' + h.shares.toLocaleString('en-US') + ' ' + k + '</div></div></div>'
      + '<div data-spark="' + (up ? 1 : 0) + '"></div>'
      + '<div><div class="val">' + money(h.shares * h.p) + '</div>'
      + '<div class="chg ' + (up ? 'up' : 'down') + '">'
      + (up ? '+' : '') + meta.d.toFixed(2) + '%</div></div></div>');
  });

  box.innerHTML = rows.join('');
  el('walCount').textContent = Object.keys(s.holdings).length + ' share positions · '
    + money(FT.holdingsValue()) + ' $FTR at market';
  box.querySelectorAll('[data-spark]').forEach(function(d){
    d.innerHTML = spark(d.dataset.spark === '1', 88, 26);
  });
}

// ── ledger ──
var LICON = { BUY:'candle', SELL:'candle', STAKE:'bolt', PAYOUT:'trophy', CONVERT:'swap',
              DEPOSIT:'wallet', WITHDRAW:'bank', SEND:'hand', SWAP:'swap', SETTLE:'trophy' };
function renderLedger(){
  var s = FT.getState(), lb = el('ledgerBody');
  if(!lb) return;
  if(!s.transactions || !s.transactions.length){
    lb.innerHTML = '<div class="empty-state"><svg class="ic-xl" aria-hidden="true"><use href="#i-receipt"/></svg>'
      + 'No movements yet. Buy $FTR or a first share to start the ledger.</div>';
    return;
  }
  lb.innerHTML = s.transactions.slice(0, 8).map(function(t){
    var down = ['BUY','STAKE','SEND','WITHDRAW'].indexOf(t.type) > -1;
    var label = t.type === 'BUY' ? 'Bought ' + t.shares.toLocaleString('en-US') + ' ' + t.asset
      : (t.type === 'SELL' ? 'Sold ' + t.shares.toLocaleString('en-US') + ' ' + t.asset
      : (t.type === 'STAKE' ? 'Staked ' + t.asset
      : (t.type === 'SEND' ? 'Sent to ' + t.asset
      : (t.type === 'SWAP' ? 'Swapped ' + t.asset : t.asset))));
    return '<div class="tx"><span class="w">'
      + '<svg class="ic-sm" aria-hidden="true"><use href="#i-' + (LICON[t.type] || 'receipt') + '"/></svg>'
      + '<span>' + label + '</span></span>'
      + '<span style="color:var(--dim);font-size:12.5px">'
      + (t.type === 'BUY' || t.type === 'SELL' ? 'Exchange' : t.type) + '</span>'
      + '<span class="num" style="font-size:12.5px;color:var(--faint)">' + (t.points ? '+' + t.points + ' FP' : '—') + '</span>'
      + '<span class="num ' + (down ? 'down' : 'up') + '">' + (down ? '−' : '+')
      + money(Math.abs(t.total)) + '</span></div>';
  }).join('');
}

// ── deposit / withdraw ──
el('depositBtn').addEventListener('click', function(e){
  e.preventDefault();
  openModal('<h3 class="ft-modal-title">Deposit $FTR</h3>'
    + '<p class="ft-modal-desc">Add prototype funds straight to your wallet balance.</p>'
    + '<div class="field"><label>Amount ($FTR)</label><input id="depAmt" value="25,000" inputmode="numeric"></div>'
    + '<div class="quick"><button data-dep="5000">5K</button><button data-dep="25000">25K</button>'
    + '<button data-dep="50000">50K</button><button data-dep="100000">100K</button></div>'
    + '<div style="display:flex;gap:10px;margin-top:18px">'
    + '<button class="btn btn-lime" id="depGo" type="button" style="flex:1;justify-content:center">Confirm deposit</button>'
    + '<button class="btn btn-glass" id="depNo" type="button" style="flex:1;justify-content:center">Cancel</button></div>');
  var inp = el('depAmt');
  document.querySelectorAll('[data-dep]').forEach(function(b){
    b.addEventListener('click', function(){ inp.value = (+b.dataset.dep).toLocaleString('en-US'); });
  });
  el('depNo').addEventListener('click', closeModal);
  el('depGo').addEventListener('click', function(){
    var a = num(inp.value);
    if(a <= 0){ showToast('Enter a valid amount.', 'error'); return; }
    FT.depositFtr(a); closeModal();
    showToast(money(a) + ' $FTR deposited.', 'success');
  });
});

el('withdrawBtn').addEventListener('click', function(e){
  e.preventDefault();
  var s = FT.getState();
  openModal('<h3 class="ft-modal-title">Withdraw $FTR</h3>'
    + '<p class="ft-modal-desc">Convert $FTR back to your verified payout account. Locked stakes cannot be '
    + 'withdrawn until their window settles.</p>'
    + '<div class="field"><label>Amount ($FTR)</label><input id="wdAmt" value="10,000" inputmode="numeric"></div>'
    + '<div class="ft-modal-card">'
    + '<div class="m-row"><span>Available</span><b>' + money(s.wallet.balance) + ' $FTR</b></div>'
    + '<div class="m-row"><span>Locked in entries</span><b>' + money(s.wallet.locked) + ' $FTR</b></div>'
    + '<div class="m-row total"><span>Withdrawal fee</span><b>0.5% · minimum 50 $FTR</b></div></div>'
    + '<div style="display:flex;gap:10px">'
    + '<button class="btn btn-lime" id="wdGo" type="button" style="flex:1;justify-content:center">Withdraw</button>'
    + '<button class="btn btn-glass" id="wdNo" type="button" style="flex:1;justify-content:center">Cancel</button></div>');
  el('wdNo').addEventListener('click', closeModal);
  el('wdGo').addEventListener('click', function(){
    try {
      var r = FT.sendFtr(num(el('wdAmt').value), 'Payout account (GBP)', 'withdraw');
      closeModal();
      showToast(money(r.sent) + ' $FTR withdrawn · ' + money(r.fee) + ' $FTR fee.', 'success');
    } catch(err){ showToast(err.message, 'error'); }
  });
});

// ── sync ──
function syncWallet(){
  var s = FT.getState();
  el('walBal').innerHTML = s.wallet.balance.toLocaleString('en-US') + '<small> $FTR</small>';
  el('walGbp').textContent = '≈ £' + Math.round(s.wallet.balance / 12.4).toLocaleString('en-US');
  renderAssets(); renderLedger(); fillSwap(); sendAfter();
}
paint('1D'); syncWallet(); conv();
window.addEventListener('fantrade:statechange', syncWallet);
"""
page("ftr.html", "$FTR — Fantrade", "".join(f), FTR_JS, FTR_CSS, app=True)


# ══════════════════════════════════════════════════════════
# HOW IT WORKS
# ══════════════════════════════════════════════════════════
HIW_CSS = """
.walk{display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:center;margin-bottom:16px}
.walk.flip .art{order:-1}
.walk .body{padding:44px 40px}
.walk .n{font-family:Archivo;font-variation-settings:'wdth' 125,'wght' 900;font-size:clamp(52px,7vw,86px);
  color:transparent;-webkit-text-stroke:1px rgba(196,248,42,.5);line-height:.85}
.walk h3{font-size:clamp(26px,3.4vw,38px);margin:18px 0 14px}
.walk p{color:var(--dim);font-weight:300;font-size:14.5px;max-width:46ch;margin:0}
.walk ul{list-style:none;padding:0;margin:22px 0 0;font-size:13px;color:var(--dim)}
.walk li{padding:10px 0;border-top:1px solid rgba(255,255,255,.055);display:flex;gap:12px;align-items:center}
.walk li .ic{color:var(--lime);width:15px;height:15px}
.art{min-height:280px;display:grid;place-items:center;position:relative;overflow:hidden;
  background:radial-gradient(ellipse at 50% 40%,rgba(196,248,42,.10),transparent 62%)}
.art .glyph{width:104px;height:104px;color:var(--lime);opacity:.9;fill:currentColor;
  filter:drop-shadow(0 18px 40px rgba(196,248,42,.28))}
.art.am{background:radial-gradient(ellipse at 50% 40%,rgba(255,106,31,.10),transparent 62%)}
.art.am .glyph{color:var(--amber);filter:drop-shadow(0 18px 40px rgba(255,106,31,.26))}
.art .ring{position:absolute;border:1px solid rgba(255,255,255,.06);border-radius:50%}
.art .r1{width:180px;height:180px}.art .r2{width:250px;height:250px}.art .r3{width:320px;height:320px}
.cmp{display:grid;grid-template-columns:1.3fr 1fr 1fr;gap:14px;padding:16px 26px;
  border-bottom:1px solid rgba(255,255,255,.05);font-size:13.5px;align-items:center}
.cmp.h{font-weight:600;font-size:9.5px;letter-spacing:.16em;color:var(--faint);text-transform:uppercase;border-bottom:1px solid var(--hair)}
.cmp .y{color:var(--lime);display:flex;align-items:center;gap:8px}
.cmp .n{color:var(--faint);display:flex;align-items:center;gap:8px}
.cmp .ic{width:15px;height:15px}
details{border-bottom:1px solid rgba(255,255,255,.06)}
details summary{list-style:none;cursor:pointer;padding:22px 0;display:flex;align-items:center;gap:16px;
  font-family:Archivo;font-variation-settings:'wdth' 115,'wght' 700;text-transform:uppercase;font-size:15px}
details summary::-webkit-details-marker{display:none}
details summary .pm{margin-left:auto;width:28px;height:28px;border-radius:999px;border:1px solid var(--hair);
  display:grid;place-items:center;color:var(--dim);transition:transform .7s var(--ease),background .6s var(--ease)}
details[open] summary .pm{transform:rotate(45deg);background:var(--lime);color:#0A0D03;border-color:var(--lime)}
details p{color:var(--dim);font-weight:300;font-size:14px;max-width:62ch;padding:0 0 22px}
.tl{display:flex;gap:0;margin-top:10px;flex-wrap:wrap}
.tl div{flex:1;min-width:150px;padding:22px 20px;border-left:1px solid var(--hair);position:relative}
.tl div:first-child{border-left:0}
.tl .k{font-weight:600;font-size:9.5px;letter-spacing:.16em;color:var(--faint);text-transform:uppercase}
.tl .v{font-family:'JetBrains Mono',monospace;font-size:16px;margin-top:10px}
.tl .d{font-size:12.5px;color:var(--dim);font-weight:300;margin-top:8px;line-height:1.5}
@media (max-width:900px){.walk{grid-template-columns:1fr}.walk.flip .art{order:0}.art{min-height:200px}
 .walk .body{padding:30px 26px}.cmp{grid-template-columns:1.2fr .8fr .8fr;padding:14px 18px}}
"""

WALK = [
    ("01", "ball", "Fund your balance", "Deposit and convert to $FTR. That single balance is what you trade with, "
     "stake with and get paid into — there is no second currency to manage.",
     ["Convert at the rate shown, fee included", "Balance splits into available and locked"], False),
    ("02", "candle", "Buy players and coaches", "Every asset carries a fixed ten million shares. Buy one share or a "
     "hundred thousand — you own a real slice of that player's Fantrade market.",
     ["Players and coaches trade on the same book", "0.4% fee on both sides, always shown first"], False),
    ("03", "crest", "Build your Dream Club", "Name it, badge it, pick a coach and a shape. Every slot checks your "
     "wallet before it accepts a player, so the squad is genuinely yours.",
     ["1 coach, 11 starters, a working bench", "Change the formation and the shape rebuilds"], True),
    ("04", "bolt", "Enter a round", "Play a single player or send the whole club. Pick a market tier and the "
     "projected points update before you commit anything.",
     ["Six tiers from Simple to Viynx Max", "Club mode earns a configurable boost"], False),
    ("05", "clock", "The window settles", "Real fixtures do the scoring. When the matchday clock closes, every "
     "eligible performance is collected and converted into Fantrade Points.",
     ["Your players can be in different matches", "Bench subs in under your own rules"], False),
    ("06", "trophy", "Get paid, then reinvest", "Points convert to $FTR and land back in your wallet. Most managers "
     "put it straight back into the next player.",
     ["Club value moves with the squad underneath", "Rankings update at the end of every round"], True),
]

h = []
h.append(T('<header class="phead"><div class="wrap">'
           '<span class="pill" data-reveal>@@ The whole loop</span><h1 data-reveal>How Fantrade<br>works</h1>'
           '<p class="lede" data-reveal>Six steps, one balance, and a rule that holds all of it together: you can only '
           'play what you actually own.</p><div style="margin-top:34px" data-reveal>@@</div></div></header>',
           ic("swap", "ic"), btn("Start with the exchange", href="exchange.html")))

h.append('<main><section style="padding-top:20px"><div class="wrap">')
for n, icon, t, d, items, am in WALK:
    lis = "".join(T("<li>@@@@</li>", ic("check", "ic"), x) for x in items)
    art = T('<div class="bezel" data-reveal><div class="core art @@"><span class="ring r1"></span>'
            '<span class="ring r2"></span><span class="ring r3"></span>'
            '<svg class="glyph" aria-hidden="true"><use href="#i-@@"/></svg></div></div>',
            "am" if am else "", icon)
    body = T('<div class="bezel" data-reveal><div class="core body"><div class="n">@@</div>'
             '<h3>@@</h3><p>@@</p><ul>@@</ul></div></div>', n, t, d, lis)
    h.append(T('<div class="walk @@">@@@@</div>', "flip" if am else "", body, art))
h.append('</div></section>')

# settlement timeline
h.append(T('<section><div class="wrap"><div class="sec-head" data-reveal>'
           '<span class="pill">@@ Settlement</span><h2>One clock,<br>not one fixture</h2>'
           '<p class="lede">A round is a window, not a match. It opens, it locks, the fixtures play out, and everyone '
           'is scored on the same data at the same moment.</p></div>'
           '<div class="bezel" data-reveal><div class="core"><div class="tl">'
           '<div><div class="k">Opens</div><div class="v">Mon 09:00</div><div class="d">Entries accepted. Lineups, '
           'captain and market tier can be changed freely.</div></div>'
           '<div><div class="k">Locks</div><div class="v">Fri 18:30</div><div class="d">No further changes. Ownership '
           'is verified once and frozen for the round.</div></div>'
           '<div><div class="k">Plays out</div><div class="v">Fri–Sun</div><div class="d">Eligible performances are '
           'collected across every tracked fixture.</div></div>'
           '<div><div class="k">Settles</div><div class="v">Mon 02:00</div><div class="d">Points convert to $FTR. '
           'Stakes release, rankings update.</div></div></div></div></div></div></section>', ic("clock", "ic")))

# comparison
CMP = [("Requires ownership", 1, 1), ("Number of assets scored", "1", "up to 16"),
       ("Coach modifier applies", 0, 1), ("Chemistry boost available", 0, 1),
       ("Captain multiplier", 0, 1), ("Bench auto-substitution", 0, 1),
       ("Simplest to enter", 1, 0)]
h.append(T('<section><div class="wrap"><div class="sec-head" data-reveal>'
           '<span class="pill amber">@@ Choosing a mode</span><h2>Individual<br>or club</h2></div>'
           '<div class="bezel" data-reveal><div class="core">'
           '<div class="cmp h"><span></span><span>Individual</span><span>Dream Club</span></div>', ic("scales", "ic")))
for label, a, b in CMP:
    def cell(v):
        if v == 1: return T('<span class="y">@@Yes</span>', ic("check", "ic"))
        if v == 0: return T('<span class="n">@@No</span>', ic("cross", "ic"))
        return '<span class="num" style="font-size:13px">%s</span>' % v
    h.append(T('<div class="cmp"><span>@@</span>@@@@</div>', label, cell(a), cell(b)))
h.append('</div></div></div></section>')

# faq
FAQ = [("Do I need all eleven players in the same match?",
        "No. Your club scores wherever its players are playing. Fantrade collects eligible performances across every "
        "tracked fixture in the window and settles them together on one clock."),
       ("What happens if a starter doesn't play?",
        "An eligible bench player is substituted in automatically, under the rules you configured when you built the "
        "club. That is why a full bench is worth more than four names and a gap."),
       ("Can I put a player I don't own in my club?",
        "No. Ownership is validated when you add a player and again when the round locks. If the shares aren't in your "
        "wallet, the name doesn't enter the teamsheet."),
       ("How is club value calculated?",
        "The current market value of your starting eleven, plus your bench, plus your coach. It moves whenever the "
        "underlying assets move, which is why the club itself becomes something worth building."),
       ("What does the coach actually do?",
        "For now the coach provides a club modifier rather than his own scoring engine. A coach whose real shape "
        "matches your formation contributes his full bonus."),
       ("Are Dream Clubs tradable?",
        "Not at launch. A club is a portfolio and a FanPlay identity. Club-to-club competition and rankings come first.")]
h.append(T('<section><div class="wrap"><div class="sec-head" data-reveal>'
           '<span class="pill">@@ Questions</span><h2>Before you<br>start</h2></div>'
           '<div class="bezel" data-reveal><div class="core" style="padding:10px 34px 20px">', ic("list", "ic") if False else ic("check", "ic")))
for q, a in FAQ:
    h.append(T('<details><summary>@@<span class="pm">@@</span></summary><p>@@</p></details>',
               q, ic("cross", "ic-sm"), a))
h.append('</div></div></div></section>')

h.append(T('<section style="padding-top:60px"><div class="wrap" style="text-align:center">'
           '<h2 data-reveal>Ready to own<br>your first player?</h2>'
           '<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:34px" data-reveal>'
           '@@@@</div></div></section></main>',
           btn("Browse the exchange", href="exchange.html"),
           btn("See a Dream Club", "btn-glass", "clubs.html")))

page("how-it-works.html", "How it works — Fantrade", "".join(h), "", HIW_CSS)
print("built ftr.html + how-it-works.html")
